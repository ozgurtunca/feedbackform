<?php 


function sanitize_event_time($event_time) {

  // General sanitization, to get rid of malicious scripts or characters
  
  $event_time = filter_var($event_time, FILTER_SANITIZE_STRING);

  // Validation to see if it is the right format

      return $event_time;
 


}

/**
* Validates that a date string is in the right format
* default format is 'g:i a' to test for time only in this format '5:00 am'
* but you can pass a new format to test against other formats
* other formats here https://www.lehelmatyus.com/1003/android-change-date-format-from-utc-to-local-time
* 
* @return bool
*/

function _my_validate_date($date, $format = 'a g:i') {
  // Create the format date
  $d = DateTime::createFromFormat($format, $date);

  // Return the comparison    
  return $d && $d->format($format) === $date;
}

if (isset($_POST["date"])) {
  $event_time = $_POST["date"];
  echo sanitize_event_time($event_time);
}


/**
* To use the code written above just call the function
*/

// $date = ...



?>

<!DOCTYPE html>
<html>
<body>

<h1>Display a Telephone Input Field</h1>

<form action="test.php" name='form' method="POST">
  <label for="date">Enter a phone number:</label><br><br>
  <input type="date" id="date" name="date"  required><br><br>
  <small></small><br><br>
  <input type="submit">
</form>

</body>
</html>
